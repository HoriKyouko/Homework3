James Williamson
Timothy Garrett

# Homework4
Our project for Homework4 involving Homework3, revides to include procedure, call, and else.

Compile instructions:

A makefile is included. you should be able to compile like so:

First start off by typing in: "make" without the quotation marks.
This should build 4 executable files from the other four .c files.

Secondly all you will need to type in is: "./cd -l -a -v" without the
quotation marks. You may also do ./cd -v or ./cd and it will compile.

If you are getting some weird spacing issues it may be because of the command
line box itself so I recommend expanding your command line box and running it
again. This is what I did to fix some weird spacing issues when it came to the 
VM output.

Arguments can be in any order/any number

In order for the program to run properly, there must be a text file containing pl0 code called "input.txt"
